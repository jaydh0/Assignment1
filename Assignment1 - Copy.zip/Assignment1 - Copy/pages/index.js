import React, { useState } from "react";
import Navy from "@/components/nav";
import DarkModePage from  "@/pages/darkmode";


export default function App() {
  const navItems = [
    { id: 1, name: "Home" },
    { id: 2, name: "About" },
    { id: 3, name: "Applications" },
  ];
  return (
    <div>
      <h1
        style={{
          textAlign: "center",
          marginBottom: "10px",
          marginTop: "10px",
          fontFamily: "sans-serif, georgia",
          textTransform: "uppercase",
          color: "Darkslategray",
        }}
      >
        Welcome!
      </h1>
      <Navy items={navItems} />
      <section>
        <p
          style={{
            width: "35%",
            margin: "auto",
            backgroundColor: "green",
            padding: "20px",
            borderRadius: "12px",
            border: "solid, white",
            marginTop: "50px",
          }}
        >
          This is a small web application page that I made, featuring a click counter page, an about me page, and a form validating page.
        </p>

        <p style={{
            width: "35%",
            margin: "auto",
            backgroundColor: "green",
            padding: "20px",
            borderRadius: "12px",
            border: "solid, white",
            marginTop: "15px",
          }}
          
          >On the about me page is just small, not too relevant information about me and my coding journey so far since ive started attending Humber Polytechnic last year September. </p>
      </section>
    </div>
  );
}
