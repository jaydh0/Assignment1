import React, { useState } from 'react';
import Link from 'next/link';
import styles from '../styles/Clickcounter.module.css'; 
import Toggle from "@/components/toggle"; 

export default function ClickCounter() {
  const [count, setCount] = useState(0);

  return (
    <div className={styles.container}>
      <h1 className={styles.heading}>Welcome to my Clicking page!</h1>
      <p className={styles.description}>With this page, you can track each click with just one button!</p>
      <h2 className={styles.counterTitle}>Click Counter</h2>
      <p className={styles.counter}>You clicked {count} times</p>
      <button className={styles.button} onClick={() => setCount(count + 1)}>Click me</button>
      <Toggle />
      <Link href="/" passHref>
        <p className={styles.link}>Go Back Home</p>
      </Link>
   
    </div>
  );
}
