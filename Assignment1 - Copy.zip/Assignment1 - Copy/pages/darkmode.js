import { useState } from "react";
import Link from "next/link";

export default function DarkModePage() {
  const [darkMode, setDarkMode] = useState(false); 

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <div style={{ 
      backgroundColor: darkMode ? "black" : "white", 
      color: darkMode ? "white" : "black",
      height: "100vh",
      textAlign: "center",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <h1>Dark Mode Toggle</h1>
      <button 
        onClick={toggleDarkMode} 
        style={{
          padding: "10px 20px",
          fontSize: "16px",
          backgroundColor: darkMode ? "whie" : "red",
          color: "white",
          border: "none",
          cursor: "pointer",
          borderRadius: "5px",
          marginTop: "10px"
        }}
      >
        {darkMode ? "LIGHT" : "DARK"}
      </button>
      <p>This is a simple dark mode toggle.</p>
      <Link href="/" style={{ marginTop: "20px", textDecoration: "underline" }}><button style={{padding: "15px", borderRadius: "10px", backgroundColor: "green"}}>Go Back Home</button></Link>
    </div>
  );
}
