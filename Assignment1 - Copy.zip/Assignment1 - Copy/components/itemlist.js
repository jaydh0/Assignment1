export default function ItemList({ items = [], onSelect }) {
  return (
    <div>
      <h2>Item List</h2>
      {items.length === 0 ? ( 
        <p style={{ color: "red" }}>⚠️ No items found!</p>
      ) : (
        <ul>
          {items.map((item) => (
            <li key={item.name} onClick={() => onSelect(item)} style={{ cursor: "pointer" }}>
              {item.name}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
