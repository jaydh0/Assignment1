import React from "react";
import Link from "next/link";
import styles from "@/styles/nav.module.css"; // Import CSS module

function Navy() {
  const items = [
    { id: 1, name: "Home", link: "/" },
    { id: 2, name: "Dark mode", link: "/darkmode" },
    { id: 3, name: "Applications", link: "/click" },
  ];

  return (
    <nav className={styles.navbar}>
      {items.map((item) => (
        <Link key={item.id} href={item.link} className={styles.navItem}>
          {item.name}
        </Link>
      ))}
    </nav>
  );
}

export default Navy;
