import { useState } from 'react';
import styles from '../styles/Clickcounter.module.css';

export default function Toggle() { 
  const [isVisible, setIsVisible] = useState(true);

  return (
    <div>
      <h2 className={styles.h2Tog}>Toggle Component</h2>
   
      <div className={styles.buttonContainer}>
        <button className={styles.toggleButton} onClick={() => setIsVisible(!isVisible)}>
          Toggle Message
        </button>
      </div>
      {isVisible && <p className={styles.ConMsg}>This is a conditionally rendered message!</p>}
    </div>
  );
}
